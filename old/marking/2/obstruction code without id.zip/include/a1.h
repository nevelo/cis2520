#include <ncurses.h>
#include <stdio.h>

void arrowInput(char dir);
void menu1();
int menu3();
int board(int size);
int okFill(int y, int x);
